const json = {
    val: 1,
    children: [{
            val: 2,
            children: [{
                    val: 4
                },
                {
                    val: 5
                }
            ]
        },
        {
            val: 3,
            children: [{
                    val: 6
                },
                {
                    val: 7
                }
            ]
        }
    ]
}

//     1
//   /  \
//   2    3
//  / \  / \
// 4  5 6   7

function bfs(root) { // 1 2 3 4 5 6 7
    const set = new Set()
    const queue = []
    queue.push(root)

    while (queue.length > 0) {
        root = queue.shift()
        console.log(root)
        if (root.children != null) {
            for (let child of root.children) {
                queue.push(child)
            }
        }
    }
}

bfs(json)

function findById (root, id) {
    if(root == null) return null
    if (root != null && root.getAttribute('id') == id) {
        return root
    }
    const children = root.children
    if (children != null) {
        for (let child of children) {
            const res = findById(child, id)
            if (res) {
                return res
            }
        }
    }
}
