const common = require('./common')

function sort(arr) {
    const bucket = []
    arr.forEach(e => {
        bucket[e] = bucket[e] ? bucket[e] + 1: e
    });
    let i = 0
    bucket.filter(v => v)
        .forEach((cnt, index) => {
            while (cnt > 0) {
                cnt--
                arr[i++]=index
            }
        })
}

common.test(sort)
