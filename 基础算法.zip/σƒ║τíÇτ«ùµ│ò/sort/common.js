
/**
 * 创建长度为N的数组，元素值为[0, N - 1]
 * @param {*} N
 */
function createRandomArray(N) {
    return new Array(N)
        .fill(1)
        .map((_, i) => i)
        .sort(() => Math.random() - 0.5)
}

function equals (a, b) {
    if(a.length != b.length) return false
    for (let i = 0; i < a.length; i++) {
        if (a[i] != b[i]) {
            return false
        }
    }
    return true
}

function test (fn, testCnt = 1000, length = 10000) {
    const start = Date.now()
    for (let i = 0; i < testCnt; i++) {
        const arr = createRandomArray(length)
        arr.sort((a, b) => a - b)
        const newArr = Array.from(arr)
        fn(newArr)
        if (!equals(arr, newArr)) {
            throw new Error('排序函数错误')
        }
    }
    console.log('排序函数正确', `${Date.now() - start}ms`)
}

function swap(arr, i, j) {
    let tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp
}

module.exports = {
    test,
    swap,
    createRandomArray
}
