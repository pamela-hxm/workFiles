const json = {
    val: 1,
    children: [{
            val: 2,
            children: [{
                    val: 4
                },
                {
                    val: 5
                }
            ]
        },
        {
            val: 3,
            children: [{
                    val: 6
                },
                {
                    val: 7
                }
            ]
        }
    ]
}

//      1
//    /  \
//   2    3
//  / \  / \
// 4  5 6   7

function dfs(root) {// 1 2 4 5 3 6 7
    const set = new Set()
    const stack = []
    set.add(root)
    console.log(root.val)
    stack.push(root)

    while (stack.length > 0) {
        root = stack.pop()
        if (root.children != null) {
            for (let child of root.children) {
                if(set.has(child)) continue
                stack.push(root)
                stack.push(child)
                console.log(child.val)
                set.add(child)
                break
            }
        }
    }
}


function findById (root, id) {
 const set = new Set()
 const stack = []
 set.add(root)
 console.log(root.val)
 stack.push(root)

 while (stack.length > 0) {
     root = stack.pop()
     if (root.children != null) {
         for (let child of root.children) {
             if (set.has(child)) continue
             if (child.getAttribute('id') == id) {
                 return child
             }
             stack.push(root)
             stack.push(child)
             console.log(child.val)
             set.add(child)
             break
         }
     }
 }
}

dfs(json)
