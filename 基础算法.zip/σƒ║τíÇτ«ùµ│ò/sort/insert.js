const common = require('./common')
const swap = common.swap


function sort(arr) {
  for (let i = 1; i < arr.length; i++) {
    for (let j = i; j > 0 && arr[j] < arr[j - 1]; j--) {
      swap(j, j - 1);
    }
  }
}

common.test(sort)
