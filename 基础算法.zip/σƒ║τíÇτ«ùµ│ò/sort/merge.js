function merge(aArr, bArr) {
    const res = []
    let aIndex = 0
    let bIndex = 0
    while (aIndex < aArr.length && bIndex < bArr.length) {
        res.push(aArr[aIndex] < bArr[bIndex] ? aArr[aIndex++] : bArr[bIndex++])
    }
    while (aIndex < aArr.length) {
        res.push(aArr[aIndex++])
    }
    while (bIndex < bArr.length) {
        res.push(bArr[bIndex++])
    }
    return res
}
