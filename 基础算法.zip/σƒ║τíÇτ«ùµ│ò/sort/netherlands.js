const common = require('./common')
const swap = common.swap
const create = common.createRandomArray

function parition (arr, value) {
    let l = -1
    let r = arr.length
    let cur = 0
    while (cur < r) {
        if (arr[cur] < value) {
            swap(arr, ++l, cur++)
        } else if (arr[cur] > value) {
            swap(arr, --r, cur)
        } else {
            cur++
        }
    }
}


let hasErr = false
out: for (let j = 0; j < 100; j++) {
    const arr = create(50)
    const target = 25
    parition(arr, target)
    let l = 0
    for (; l < arr.length && arr[l] < target; l++);
    let r = arr.length - 1
    for (; r >= 0 && arr[r] > target; r--);
    for (let i = l; i <= r; i++) {
        if (arr[i] != target) {
            hasErr = true
            break out
        }
    }
}

console.log(hasErr ? '错误': '成功')


