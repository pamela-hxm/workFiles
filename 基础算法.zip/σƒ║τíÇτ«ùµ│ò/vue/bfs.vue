<template>
  <div>
      <div>从左上角走到右下角的走法</div>
      <button @click="next">next</button>
      <ul v-for="(row, index) in matrix" :key="index">
          <li ref="li" v-for="(col, index) in row" :key="index"></li>
      </ul>
  </div>
</template>
<script>
import {addClass} from './utils'
export default {
  data() {
    return {
      matrix: new Array(5).fill(1).reduce((pre) => {
        pre.push(new Array(5));
        return pre;
      }, []),
      gen: null,
      domMatrix: null
    };
  },
  mounted() {
      this.gen = this.dfs()
  },
  methods: {
      next() {
        this.gen.next()
      },
      *dfs() {
          this.domMatrix = this.getDomMatrix()
          const queue = []
          const set = new Set()
          yield
          queue.push({
              i: 0,
              j: 0,
              removeClass: this.addClass(0, 0)
          })
          while(queue.length > 0) {
              console.log('next')
              const cur = queue.shift()
              this.addTouched(cur)
              const a = this.getNode(set, cur.i+1, cur.j)
              const b = this.getNode(set, cur.i, cur.j+1)
              yield
              if(a) {
                  set.add(a)
                  queue.push({
                      i: cur.i + 1,
                      j: cur.j,
                      removeClass: this.addClass(cur.i + 1, cur.j)
                  })
              }
              if(b) {
                  set.add(b)
                  queue.push({
                      i: cur.i,
                      j: cur.j + 1,
                      removeClass: this.addClass(cur.i, cur.j + 1)
                  })
              }
            //   cur.removeClass()
          }
      },
      addTouched({i, j}) {
          const node = this.domMatrix[i][j]
          return addClass(node, 'touched')
      },
      addClass(i, j) {
          const node = this.domMatrix[i][j]
          return addClass(node, 'actived')
      },
      getNode(set, i, j) {
          if(i >= this.domMatrix.length || i < 0 || j >= this.domMatrix.length || j < 0) {
              return null
          }
          if(set.has(this.domMatrix[i][j])) {
              return null
          }
          set.add(this.domMatrix[i][j])
          return this.domMatrix[i][j]
      },
      getDomMatrix() {
          const arr = this.$refs.li
          const matrix = []
          for(let i = 0 ; i < 5; i++) {
              const row = []
              for(let j = 0; j < 5; j++) {
                  row.push(arr[i*5+j])
              }
              matrix.push(row)
          }
          return matrix
      }
  }
};
</script>
<style scoped>
ul {
    list-style: none;
    font-size: 0;
    margin: 0;
    padding: 0;
}
li {
    display: inline-block;
    width: 50px;
    height: 50px;
    border: 1px solid black;
}
.actived {
    background-color: red;
}

.touched {
    background-color: green;
}
</style>
