<template>
  <div id="flip-list-demo" class="demo">
    <button @click="rand">随机</button>
    <button @click="next">next</button>
    <br>
    <div>
        <span class="red">当前元素下标: {{from}}</span>
        <span class="blue">相邻元素下标: {{to}}</span>
        <span class="green">已排序元素</span>
    </div>
    <transition-group name="flip-list" tag="ul">
      <li ref="el" v-for="item in arr" :key="item">
        {{ item }}
      </li>
    </transition-group>
    <ul class="index-list">
      <li ref="index" v-for="item in indexList" :key="item">
        {{ item }}
      </li>
    </ul>
    {{text}}
  </div>
</template>

<script>
import { createRandomArray, swap, addClass } from "./utils";
export default {
  data() {
    return {
      arr: [],
      indexList: [],
      from: null,
      to: null,
      text: null
    };
  },
  methods: {
    rand() {
      this.arr = createRandomArray(5);
      this.indexList = this.arr.map((_, index) => index)
      this.text = null
      this.gen = this.bubbleSort(this.arr);
    },
    next() {
      const res = this.gen.next();
      if(res.done) {
          this.text = '排序完成'
      }
    },
    addClassWrapper(el, str) {
        return (i) => {
            const rm = addClass(el[i], str)
            this[str] = i
            return rm
        };
    },
    swapElAndIndex(el, arr) {
        return (i, j) =>  {
            swap(el, i, j)
            swap(arr, i, j)
        }
    },
    *bubbleSort(arr) {
      let el = this.$refs.el;

      const from = this.addClassWrapper(el, 'from')
      const to = this.addClassWrapper(el, 'to')
      const swap = this.swapElAndIndex(el, arr)

      for (let i = arr.length - 1; i >= 0; i--) {
        for (let j = 0; j < i; j++) {
          const rmFrom = from(j)
          const rmTo = to(j+1)
          yield
          if (arr[j] > arr[j + 1]) {
            swap(j, j + 1)
            this.arr = [...arr]
          }
          yield
          rmFrom()
          rmTo()
        }
        addClass(el[i], 'sorted')
      }
    },
  },
};
</script>

<style scoped>
.flip-list-move {
  transition: transform .5s;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  display: inline-block;
  width: 30px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  margin-left: 5px;
  border: 3px solid black;
}
.from {
  border-color: red;
}
.to {
  border-color: blue;
}
.red::before,.blue::before, .green::before {
    content: " ";
    display: inline-block;
    width: 10px;
    height: 10px;
}
.red::before {
    background-color: red;
}
.blue {
    margin-left: 10px;
}
.blue::before {
    background-color: blue;
}

.green {
    margin-left: 10px;
}
.green::before {
    background-color: green;
}

.sorted {
    border-color: green;
}

.index-list li{
    border: none;
    padding: 0 3px;
}
</style>
