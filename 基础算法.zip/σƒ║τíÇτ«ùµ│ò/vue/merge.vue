<template>
  <div id="flip-list-demo" class="demo">
    <button @click="next">next</button>
    <br />
    <div>
      <span class="red">数组a当前元素</span>
      <span class="blue">数组b当前元素</span>
    </div>
    <transition-group name="flip-list" tag="ul">
      <li ref="aEl" v-for="item in aArr" :key="item">
        {{ item }}
      </li>
    </transition-group>
    <transition-group name="flip-list" tag="ul">
      <li ref="bEl" v-for="item in bArr" :key="item">
        {{ item }}
      </li>
    </transition-group>
    <ul class="wrapper">
      <li ref="index" v-for="item in res" :key="item">
        {{ item }}
      </li>
    </ul>
    {{ text }}
  </div>
</template>

<script>
import { swap, addClass } from "./utils";
export default {
  data() {
    return {
      aArr: [1, 3, 5, 7, 9],
      bArr: [2, 4, 6, 8],
      res: [],
      from: null,
      to: null,
      text: null,
    };
  },
  mounted() {
      this.gen = this.merge()
  },
  methods: {
    rand() {
      this.text = null;
      this.gen = this.merge(this.arr);
    },
    next() {
      const res = this.gen.next();
      if (res.done) {
        this.text = "排序完成";
      }
    },
    addClassWrapper(el, str) {
      return (i) => {
        const rm = addClass(el[i], str);
        this[str] = i;
        return rm;
      };
    },
    swapElAndIndex(el, arr) {
      return (i, j) => {
        swap(el, i, j);
        swap(arr, i, j);
      };
    },
    *merge() {
      let aEl = this.$refs.aEl;
      let bEl = this.$refs.bEl;

      const a = this.addClassWrapper(aEl, "from");
      const b = this.addClassWrapper(bEl, "to");
      let aArr = this.aArr;
      let bArr = this.bArr;
      let aIndex = 0;
      let bIndex = 0;
      let aLen = aEl.length;
      let bLen = bEl.length;
      const push = (num) => (this.res = this.res.concat([num]));
      while (aIndex < aLen && bIndex < bLen) {
        a(aIndex);
        b(bIndex);
        yield
        push(aArr[aIndex] < bArr[bIndex] ? aArr[aIndex++] : bArr[bIndex++]);
      }
      while (aIndex < aLen) {
        a(aIndex);
        yield
        push(aArr[aIndex++]);
      }
      while (bIndex < bLen) {
        b(bIndex);
        yield
        push(bArr[bIndex++]);
      }
    },
  },
};
</script>

<style scoped>
.flip-list-move {
  transition: transform 0.5s;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  display: inline-block;
  width: 30px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  margin-left: 5px;
  border: 3px solid black;
}
.from {
  border-color: red;
}
.to {
  border-color: blue;
}
.red::before,
.blue::before,
.green::before {
  content: " ";
  display: inline-block;
  width: 10px;
  height: 10px;
}
.red::before {
  background-color: red;
}
.blue {
  margin-left: 10px;
}
.blue::before {
  background-color: blue;
}

.green {
  margin-left: 10px;
}
.green::before {
  background-color: green;
}

.sorted {
  border-color: green;
}

.index-list li {
  border: none;
  padding: 0 3px;
}

.wrapper {
    display: inline-block;
    min-height: 30px;
    border: 3px black solid;
}
.wrapper li {
    border-color: green;
}
</style>
