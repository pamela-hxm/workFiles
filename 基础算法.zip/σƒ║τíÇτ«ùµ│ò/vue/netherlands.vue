<template>
  <div id="flip-list-demo" class="demo">
    <button @click="rand">随机</button>
    <button @click="next">next</button>
    <br>
    <div>
        <span class="red">左半区</span>
        <span class="blue">右半区</span>
        <span class="green">当前元素</span>
    </div>
    <transition-group name="flip-list" tag="ul">
      <li ref="el" v-for="item in arr" :key="item">
        {{ item }}
      </li>
    </transition-group>
    <ul class="index-list">
      <li ref="index" v-for="item in indexList" :key="item">
        {{ item }}
      </li>
    </ul>
    {{text}}
  </div>
</template>

<script>
import { createRandomArray, swap, addClass } from "./utils";
export default {
  data() {
    return {
      arr: [],
      indexList: [],
      from: null,
      to: null,
      text: null
    };
  },
  methods: {
    rand() {
      this.arr = createRandomArray(10);
      this.indexList = this.arr.map((_, index) => index)
      this.text = null
      this.gen = this.partition(this.arr);
    },
    next() {
      const res = this.gen.next();
      if(res.done) {
          this.text = '排序完成'
      }
    },
    addClassWrapper(el, str) {
        return (i) => {
            const rm = addClass(el[i], str)
            this[str] = i
            return rm
        };
    },
    swapElAndIndex(el, arr) {
        return (i, j) =>  {
            swap(el, i, j)
            swap(arr, i, j)
        }
    },
    *partition(arr) {
        let el = this.$refs.el;
        const swap = this.swapElAndIndex(el, arr)
        const LEFT = this.addClassWrapper(el, 'left')
        const RIGHT = this.addClassWrapper(el, 'right')
        const MIDDLE = this.addClassWrapper(el, 'middle')
        const target = 5
        let l = -1
        let r = el.length
        let cur = 0
        while(cur < r) {
            yield
            if(arr[cur] < target) {
                swap(++l, cur++)
                LEFT(l)
            }else if(arr[cur] > target) {
                swap(--r, cur)
                RIGHT(r)
            }else {
                MIDDLE(cur++)
            }
            this.arr = [...arr]
        }
    },
  },
};
</script>

<style scoped>
.flip-list-move {
  transition: transform .5s;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  display: inline-block;
  width: 30px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  margin-left: 5px;
  border: 3px solid black;
}
.left {
  border-color: red;
}
.middle {
    border-block-color: green;
}
.right {
  border-color: blue;
}
.red::before,.blue::before, .green::before {
    content: " ";
    display: inline-block;
    width: 10px;
    height: 10px;
}
.red::before {
    background-color: red;
}
.blue {
    margin-left: 10px;
}
.blue::before {
    background-color: blue;
}

.green {
    margin-left: 10px;
}
.green::before {
    background-color: green;
}

.sorted {
    border-color: green;
}

.index-list li{
    border: none;
    padding: 0 3px;
}
</style>
