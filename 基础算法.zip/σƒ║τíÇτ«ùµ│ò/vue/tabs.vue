<template>
    <div>
        <ul>
            <li v-for="{label, value} in list" :key="value" @click="current = value">
                <span :class="current === value ? 'active': null">{{label}}</span>
            </li>
        </ul>
        <component :is="current" />
    </div>
</template>
<script>
import Bubble from './bubble'
import Select from './select'
import Insert from './insert'
import DFS from './dfs'
import BFS from './bfs'
import Merge from './merge'
import Netherlands from './netherlands'

export default {
    components: {
        Bubble,
        Select,
        Insert,
        DFS,
        BFS,
        Merge,
        Netherlands
    },
    data() {
        return {
            current: null,
            list: [
                {
                    label: '冒泡排序',
                    value: 'Bubble'
                },
                {
                    label: '选择排序',
                    value: 'Select'
                },
                {
                    label: '插入排序',
                    value: 'Insert'
                },
                {
                    label: '归并基础（有序数组合并）',
                    value: 'Merge'
                },
                {
                    label: '快排基础（荷兰国旗）',
                    value: 'Netherlands'
                },
                {
                    label: '广度优先搜索',
                    value: 'BFS'
                },
                {
                    label: '深度优先搜索',
                    value: 'DFS'
                }
            ]
        }
    }
}

</script>
<style>
.flip-list-move {
  transition: transform .5s;
}
</style>
<style scoped>
.active {
    color: red;
}
li {
    display: inline;
    margin-left: 10px;
}
</style>
