



/**
 * 创建长度为N的数组，元素值为[0, N - 1]
 * @param {*} N
 */
export function createRandomArray (N) {
    return new Array(N)
        .fill(1)
        .map((_, i) => i)
        .sort(() => Math.random() - 0.5)
}

/**
 * 交换数组中元素
 * @param {*} arr 目标数组
 * @param {*} i 下标i
 * @param {*} j 下标j
 */
export function swap(arr, i, j) {
    let tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp
    return [...arr]
}

export function addClass (el, className) {
    el.classList.add(className)
    return () => {
        el.classList.remove(className)
    }
}

// export function removeClass (el) {
// }
